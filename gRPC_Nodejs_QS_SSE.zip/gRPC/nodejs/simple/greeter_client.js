var messages = require('./helloworld_pb');
var services = require('./helloworld_grpc_pb');
var grpc = require('@grpc/grpc-js');

var target = 'localhost:50051';
var client = new services.GreeterClient(target,
                                        grpc.credentials.createInsecure());
var request = new messages.HelloRequest();
request.setName('山田太郎');
client.sayHello(request, function(err, response) {
  if(err)
    console.log(err);
  else
    console.log('Greeter client received: ', response.getMessage());
  client.getChannel().close();
  process.exit(0);
});
