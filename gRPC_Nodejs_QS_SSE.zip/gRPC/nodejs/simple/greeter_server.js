var messages = require('./helloworld_pb');
var services = require('./helloworld_grpc_pb');
var grpc = require('@grpc/grpc-js');

function sayHello(call, callback) {
  //return callback({
  //  code: grpc.status.UNIMPLEMENTED,
  //  message: "Method not implemented!"
  //});
  console.log('Received request:');
  console.log(call.request);
  var reply = new messages.HelloReply();
  reply.setMessage('こんにちは ' + call.request.getName() + '!');
  callback(null, reply);
}

var server = new grpc.Server();
server.addService(services.GreeterService, {sayHello: sayHello});
server.bindAsync('0.0.0.0:50051',
                 grpc.ServerCredentials.createInsecure(),
                 (err, port) => {server.start();});
