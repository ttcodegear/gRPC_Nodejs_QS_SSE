var messages = require('./hellostreamingworld_pb');
var services = require('./hellostreamingworld_grpc_pb');
var grpc = require('@grpc/grpc-js');

function sayHello(call) {
  call.on('data', function(requestStream){
    console.log('Received request:');
    console.log(requestStream);
    var name = requestStream.getName();
    var num = Number(requestStream.getNumGreetings());
    for(var i = 0; i < num; i++) {
      var reply = new messages.HelloReply();
      reply.setMessage('こんにちは ' + name + '! ' + i);
      call.write(reply);
    }
  });
  call.on('end', function(){
    call.end();
  });
}

var server = new grpc.Server();
server.addService(services.MultiGreeterService, {sayHello: sayHello});
server.bindAsync('0.0.0.0:50052',
                 grpc.ServerCredentials.createInsecure(),
                 (err, port) => {server.start();});
