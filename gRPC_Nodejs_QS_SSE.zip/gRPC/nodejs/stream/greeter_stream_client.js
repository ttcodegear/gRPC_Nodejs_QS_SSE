var messages = require('./hellostreamingworld_pb');
var services = require('./hellostreamingworld_grpc_pb');
var grpc = require('@grpc/grpc-js');

var target = 'localhost:50052';
var client = new services.MultiGreeterClient(target,
                                           grpc.credentials.createInsecure());
var call = client.sayHello();
call.on('data', function(response){
  console.log('Greeter client received: ' + response.getMessage());
});
call.on('end', function(){
  //console.log('Receive end');
  client.getChannel().close();
  process.exit(0);
});
var requests = [];
var request1 = new messages.HelloRequest();
request1.setName('山田太郎');
request1.setNumGreetings('5');
requests.push(request1);
var request2 = new messages.HelloRequest();
request2.setName('FooBar');
request2.setNumGreetings('5');
requests.push(request2);
requests.forEach(req => call.write(req));
call.end();
