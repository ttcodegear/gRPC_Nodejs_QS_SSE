var messages = require('./helloworld_pb');
var services = require('./helloworld_grpc_pb');
var grpc = require('@grpc/grpc-js');
var fs = require('fs');

var cacert = fs.readFileSync("./server.crt");
var cert_chain = fs.readFileSync("./server.crt");
var private_key = fs.readFileSync("./server.key");
var credentials = grpc.ServerCredentials.createSsl(
  cacert, // Root CA certificates for validating client certificates
  [{cert_chain, private_key}],
  false   // checkClientCertificate(true/false)
);

function sayHello(call, callback) {
  console.log('Received request:');
  console.log(call.request);
  var reply = new messages.HelloReply();
  reply.setMessage('こんにちは ' + call.request.getName() + '!');
  callback(null, reply);
}

var server = new grpc.Server();
server.addService(services.GreeterService, {sayHello: sayHello});
server.bindAsync('0.0.0.0:50051',
                 credentials,
                 (err, port) => {server.start();});
