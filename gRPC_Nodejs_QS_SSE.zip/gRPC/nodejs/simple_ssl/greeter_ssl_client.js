var messages = require('./helloworld_pb');
var services = require('./helloworld_grpc_pb');
var grpc = require('@grpc/grpc-js');
var fs = require('fs');

var cacert = fs.readFileSync("./server.crt");
var private_key = fs.readFileSync("./server.key");
var cert_chain = fs.readFileSync("./server.crt");
var credentials = grpc.credentials.createSsl(
  cacert,
  private_key,
  cert_chain
);

var target = 'jatok-tts1:50051';
var options = {'grpc.ssl_target_name_override':'localhost'};
var client = new services.GreeterClient(target, credentials, options);
var request = new messages.HelloRequest();
request.setName('山田太郎');
client.sayHello(request, function(err, response) {
  console.log('Greeter client received: ', response.getMessage());
  client.getChannel().close();
  process.exit(0);
});
