// GENERATED CODE -- DO NOT EDIT!

'use strict';
var grpc = require('@grpc/grpc-js');
var ServerSideExtension_pb = require('./ServerSideExtension_pb.js');

function serialize_qlik_sse_BundledRows(arg) {
  if (!(arg instanceof ServerSideExtension_pb.BundledRows)) {
    throw new Error('Expected argument of type qlik.sse.BundledRows');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_qlik_sse_BundledRows(buffer_arg) {
  return ServerSideExtension_pb.BundledRows.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_qlik_sse_Capabilities(arg) {
  if (!(arg instanceof ServerSideExtension_pb.Capabilities)) {
    throw new Error('Expected argument of type qlik.sse.Capabilities');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_qlik_sse_Capabilities(buffer_arg) {
  return ServerSideExtension_pb.Capabilities.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_qlik_sse_Empty(arg) {
  if (!(arg instanceof ServerSideExtension_pb.Empty)) {
    throw new Error('Expected argument of type qlik.sse.Empty');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_qlik_sse_Empty(buffer_arg) {
  return ServerSideExtension_pb.Empty.deserializeBinary(new Uint8Array(buffer_arg));
}


// *
// The communication service provided between the Qlik engine and the plugin.
var ConnectorService = exports.ConnectorService = {
  // / A handshake call for the Qlik engine to retrieve the capability of the plugin.
getCapabilities: {
    path: '/qlik.sse.Connector/GetCapabilities',
    requestStream: false,
    responseStream: false,
    requestType: ServerSideExtension_pb.Empty,
    responseType: ServerSideExtension_pb.Capabilities,
    requestSerialize: serialize_qlik_sse_Empty,
    requestDeserialize: deserialize_qlik_sse_Empty,
    responseSerialize: serialize_qlik_sse_Capabilities,
    responseDeserialize: deserialize_qlik_sse_Capabilities,
  },
  // / Requests a function to be executed as specified in the header.
executeFunction: {
    path: '/qlik.sse.Connector/ExecuteFunction',
    requestStream: true,
    responseStream: true,
    requestType: ServerSideExtension_pb.BundledRows,
    responseType: ServerSideExtension_pb.BundledRows,
    requestSerialize: serialize_qlik_sse_BundledRows,
    requestDeserialize: deserialize_qlik_sse_BundledRows,
    responseSerialize: serialize_qlik_sse_BundledRows,
    responseDeserialize: deserialize_qlik_sse_BundledRows,
  },
  // / Requests a script to be evaluated as specified in the header.
evaluateScript: {
    path: '/qlik.sse.Connector/EvaluateScript',
    requestStream: true,
    responseStream: true,
    requestType: ServerSideExtension_pb.BundledRows,
    responseType: ServerSideExtension_pb.BundledRows,
    requestSerialize: serialize_qlik_sse_BundledRows,
    requestDeserialize: deserialize_qlik_sse_BundledRows,
    responseSerialize: serialize_qlik_sse_BundledRows,
    responseDeserialize: deserialize_qlik_sse_BundledRows,
  },
};

exports.ConnectorClient = grpc.makeGenericClientConstructor(ConnectorService);
